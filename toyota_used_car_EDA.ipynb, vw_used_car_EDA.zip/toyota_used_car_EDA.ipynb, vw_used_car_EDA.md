<a href="https://colab.research.google.com/github/SKawsar/Data_Visualization_with_Python_s2/blob/main/Lecture_3.ipynb" target="_parent"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab"/></a>

#### Import required libraries and packages


```python
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns
```

    Matplotlib is building the font cache; this may take a moment.
    

#### Read a csv file as pandas DataFrame


```python
df = pd.read_csv("toyota.csv")
print (type(df))
display(df.head())
display(df.tail())
```

    <class 'pandas.core.frame.DataFrame'>
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>model</th>
      <th>year</th>
      <th>price</th>
      <th>transmission</th>
      <th>mileage</th>
      <th>fuelType</th>
      <th>mpg</th>
      <th>engineSize</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>GT86</td>
      <td>2016</td>
      <td>16000</td>
      <td>Manual</td>
      <td>24089</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>GT86</td>
      <td>2017</td>
      <td>15995</td>
      <td>Manual</td>
      <td>18615</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>GT86</td>
      <td>2015</td>
      <td>13998</td>
      <td>Manual</td>
      <td>27469</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>GT86</td>
      <td>2017</td>
      <td>18998</td>
      <td>Manual</td>
      <td>14736</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>GT86</td>
      <td>2017</td>
      <td>17498</td>
      <td>Manual</td>
      <td>36284</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>model</th>
      <th>year</th>
      <th>price</th>
      <th>transmission</th>
      <th>mileage</th>
      <th>fuelType</th>
      <th>mpg</th>
      <th>engineSize</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6733</th>
      <td>IQ</td>
      <td>2011</td>
      <td>5500</td>
      <td>Automatic</td>
      <td>30000</td>
      <td>Petrol</td>
      <td>58.9</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>6734</th>
      <td>Urban Cruiser</td>
      <td>2011</td>
      <td>4985</td>
      <td>Manual</td>
      <td>36154</td>
      <td>Petrol</td>
      <td>50.4</td>
      <td>1.3</td>
    </tr>
    <tr>
      <th>6735</th>
      <td>Urban Cruiser</td>
      <td>2012</td>
      <td>4995</td>
      <td>Manual</td>
      <td>46000</td>
      <td>Diesel</td>
      <td>57.6</td>
      <td>1.4</td>
    </tr>
    <tr>
      <th>6736</th>
      <td>Urban Cruiser</td>
      <td>2011</td>
      <td>3995</td>
      <td>Manual</td>
      <td>60700</td>
      <td>Petrol</td>
      <td>50.4</td>
      <td>1.3</td>
    </tr>
    <tr>
      <th>6737</th>
      <td>Urban Cruiser</td>
      <td>2011</td>
      <td>4495</td>
      <td>Manual</td>
      <td>45128</td>
      <td>Petrol</td>
      <td>50.4</td>
      <td>1.3</td>
    </tr>
  </tbody>
</table>
</div>



```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6738 entries, 0 to 6737
    Data columns (total 8 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   model         6738 non-null   object 
     1   year          6738 non-null   int64  
     2   price         6738 non-null   int64  
     3   transmission  6738 non-null   object 
     4   mileage       6738 non-null   int64  
     5   fuelType      6738 non-null   object 
     6   mpg           6738 non-null   float64
     7   engineSize    6738 non-null   float64
    dtypes: float64(2), int64(3), object(3)
    memory usage: 421.2+ KB
    

#### Check for missing values, data types of the columns


```python
df.info()

# Nan - not a number
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6738 entries, 0 to 6737
    Data columns (total 8 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   model         6738 non-null   object 
     1   year          6738 non-null   int64  
     2   price         6738 non-null   int64  
     3   transmission  6738 non-null   object 
     4   mileage       6738 non-null   int64  
     5   fuelType      6738 non-null   object 
     6   mpg           6738 non-null   float64
     7   engineSize    6738 non-null   float64
    dtypes: float64(2), int64(3), object(3)
    memory usage: 421.2+ KB
    


```python
print(df.shape)

print("number of rows=", df.shape[0])
print("number of columns=", df.shape[1])
```

    (6738, 8)
    number of rows= 6738
    number of columns= 8
    

#### Count the number of unique values present in the 'year' column


```python
print(df["year"].unique())
print(type(df["year"].unique()))
print(len(df["year"].unique()))

print(df["year"].value_counts())
```

    [2016 2017 2015 2020 2013 2019 2018 2014 2012 2005 2003 2004 2001 2008
     2007 2010 2011 2006 2009 2002 1999 2000 1998]
    <class 'numpy.ndarray'>
    23
    2017    2019
    2019    1286
    2018    1015
    2016     997
    2015     525
    2014     352
    2013     204
    2020     128
    2012      42
    2011      40
    2009      29
    2007      20
    2008      19
    2010      18
    2005      12
    2006      11
    2004       7
    2003       6
    2002       4
    1998       1
    2001       1
    1999       1
    2000       1
    Name: year, dtype: int64
    

#### Count the number of unique values present in the 'model' column


```python
print(df["model"].value_counts())
```

     Yaris            2122
     Aygo             1961
     Auris             712
     C-HR              479
     RAV4              473
     Corolla           267
     Prius             232
     Avensis           115
     Verso             114
     Hilux              86
     GT86               73
     Land Cruiser       51
     PROACE VERSO       15
     Supra              12
     Camry              11
     IQ                  8
     Urban Cruiser       4
     Verso-S             3
    Name: model, dtype: int64
    

#### Count the number of unique values present in the 'transmission' column


```python
print(df["transmission"].value_counts())
```

    Manual       3826
    Automatic    2657
    Semi-Auto     254
    Other           1
    Name: transmission, dtype: int64
    

#### Count the number of unique values present in the 'fuelType' column


```python
print(df["fuelType"].value_counts())
```

    Petrol    4087
    Hybrid    2043
    Diesel     503
    Other      105
    Name: fuelType, dtype: int64
    

#### Pie Chart


```python
df["transmission"].value_counts().plot(kind="pie", 
                                       autopct='%1.1f%%', 
                                       startangle=170)

plt.ylabel("")
plt.show()
```


    
![png](output_18_0.png)
    


#### Problems with pie Chart


```python
df["fuelType"].value_counts().plot(kind="pie", 
                                       autopct='%1.1f%%', 
                                       startangle=180)
plt.ylabel("")
plt.show()
```


    
![png](output_20_0.png)
    


#### Find the percentage of unique values present in the 'fuelType' column


```python
print(df["fuelType"].value_counts())

print(type(df["fuelType"].value_counts()))

df_fuelType = pd.DataFrame(df["fuelType"].value_counts())

display(df_fuelType.head())
print(df_fuelType.index)
print(df_fuelType.columns)
```

    Petrol    4087
    Hybrid    2043
    Diesel     503
    Other      105
    Name: fuelType, dtype: int64
    <class 'pandas.core.series.Series'>
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fuelType</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Petrol</th>
      <td>4087</td>
    </tr>
    <tr>
      <th>Hybrid</th>
      <td>2043</td>
    </tr>
    <tr>
      <th>Diesel</th>
      <td>503</td>
    </tr>
    <tr>
      <th>Other</th>
      <td>105</td>
    </tr>
  </tbody>
</table>
</div>


    Index(['Petrol', 'Hybrid', 'Diesel', 'Other'], dtype='object')
    Index(['fuelType'], dtype='object')
    


```python
df_fuelType = pd.DataFrame(df["fuelType"].value_counts())
df_fuelType = df_fuelType.reset_index()
df_fuelType = df_fuelType.rename(columns={"index":"fuelType",
                                          "fuelType":"no_of_cars"})

df_fuelType["% of cars"] = (df_fuelType["no_of_cars"]/df.shape[0])*100

df_fuelType = df_fuelType.round(2)


display(df_fuelType)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fuelType</th>
      <th>no_of_cars</th>
      <th>% of cars</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Petrol</td>
      <td>4087</td>
      <td>60.66</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Hybrid</td>
      <td>2043</td>
      <td>30.32</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Diesel</td>
      <td>503</td>
      <td>7.47</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Other</td>
      <td>105</td>
      <td>1.56</td>
    </tr>
  </tbody>
</table>
</div>


#### Create a Barplot for the 'fuelType' column


```python
sns.barplot(x="fuelType", 
            y="% of cars", 
            data=df_fuelType, 
            color="blue",
            alpha=0.5)

plt.xlabel("Types of fuel")
plt.ylabel("% of cars")
plt.title("Percentage of cars present in each fuelType")

plt.yticks(np.arange(0,101,10))

plt.show()
```


    
![png](output_25_0.png)
    



```python
np.arange(0,101,10)
```




    array([  0,  10,  20,  30,  40,  50,  60,  70,  80,  90, 100])



#### Find the percentage of unique values present in the 'transmission' column


```python
df_transmission = pd.DataFrame(df["transmission"].value_counts())
df_transmission = df_transmission.reset_index()
df_transmission = df_transmission.rename(columns={"index":"transmission",
                                          "transmission":"no_of_cars"})

df_transmission["% of cars"] = (df_transmission["no_of_cars"]/df.shape[0])*100

df_transmission = df_transmission.round(2)

display(df_transmission)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transmission</th>
      <th>no_of_cars</th>
      <th>% of cars</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Manual</td>
      <td>3826</td>
      <td>56.78</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Automatic</td>
      <td>2657</td>
      <td>39.43</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Semi-Auto</td>
      <td>254</td>
      <td>3.77</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Other</td>
      <td>1</td>
      <td>0.01</td>
    </tr>
  </tbody>
</table>
</div>


#### Create a Barplot for the 'transmission' column


```python
sns.barplot(x="transmission", 
            y="% of cars", 
            data=df_transmission, 
            color="g",
            alpha=0.8)

plt.xlabel("Types of transmission")
plt.ylabel("% of cars")
plt.title("Percentage of cars present in each transmission")

plt.yticks(np.arange(0,61,10))

plt.show()
```


    
![png](output_30_0.png)
    


In case of Toyota used car exploratory data analysis, Bar plot is more preferable than pie chart. Because in case of pie chart, for transmission, the value of semi-auto and others are collapsing at one point. Similarly for fuelType as well the value of diesel and others value is showing at the same point. 

In this Bar plot is best suitable through which we can identify the differences among the values for both transmission and fueltype.
