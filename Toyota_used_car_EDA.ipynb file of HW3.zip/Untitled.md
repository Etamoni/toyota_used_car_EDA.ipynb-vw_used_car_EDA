```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_context('talk')
```


```python
df = pd.read_csv("toyota.csv")

display(df.head(10))
print(df.head())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>model</th>
      <th>year</th>
      <th>price</th>
      <th>transmission</th>
      <th>mileage</th>
      <th>fuelType</th>
      <th>mpg</th>
      <th>engineSize</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>GT86</td>
      <td>2016</td>
      <td>16000</td>
      <td>Manual</td>
      <td>24089</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>GT86</td>
      <td>2017</td>
      <td>15995</td>
      <td>Manual</td>
      <td>18615</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>GT86</td>
      <td>2015</td>
      <td>13998</td>
      <td>Manual</td>
      <td>27469</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>GT86</td>
      <td>2017</td>
      <td>18998</td>
      <td>Manual</td>
      <td>14736</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>GT86</td>
      <td>2017</td>
      <td>17498</td>
      <td>Manual</td>
      <td>36284</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>GT86</td>
      <td>2017</td>
      <td>15998</td>
      <td>Manual</td>
      <td>26919</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>GT86</td>
      <td>2017</td>
      <td>18522</td>
      <td>Manual</td>
      <td>10456</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>GT86</td>
      <td>2017</td>
      <td>18995</td>
      <td>Manual</td>
      <td>12340</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>GT86</td>
      <td>2020</td>
      <td>27998</td>
      <td>Manual</td>
      <td>516</td>
      <td>Petrol</td>
      <td>33.2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>GT86</td>
      <td>2016</td>
      <td>13990</td>
      <td>Manual</td>
      <td>37999</td>
      <td>Petrol</td>
      <td>36.2</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>


       model  year  price transmission  mileage fuelType   mpg  engineSize
    0   GT86  2016  16000       Manual    24089   Petrol  36.2         2.0
    1   GT86  2017  15995       Manual    18615   Petrol  36.2         2.0
    2   GT86  2015  13998       Manual    27469   Petrol  36.2         2.0
    3   GT86  2017  18998       Manual    14736   Petrol  36.2         2.0
    4   GT86  2017  17498       Manual    36284   Petrol  36.2         2.0
    


```python
print (df.shape)
```

    (6738, 8)
    


```python
display (df.describe())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>price</th>
      <th>mileage</th>
      <th>mpg</th>
      <th>engineSize</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>6738.000000</td>
      <td>6738.000000</td>
      <td>6738.000000</td>
      <td>6738.000000</td>
      <td>6738.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2016.748145</td>
      <td>12522.391066</td>
      <td>22857.413921</td>
      <td>63.042223</td>
      <td>1.471297</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.204062</td>
      <td>6345.017587</td>
      <td>19125.464147</td>
      <td>15.836710</td>
      <td>0.436159</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1998.000000</td>
      <td>850.000000</td>
      <td>2.000000</td>
      <td>2.800000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2016.000000</td>
      <td>8290.000000</td>
      <td>9446.000000</td>
      <td>55.400000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2017.000000</td>
      <td>10795.000000</td>
      <td>18513.000000</td>
      <td>62.800000</td>
      <td>1.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2018.000000</td>
      <td>14995.000000</td>
      <td>31063.750000</td>
      <td>69.000000</td>
      <td>1.800000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2020.000000</td>
      <td>59995.000000</td>
      <td>174419.000000</td>
      <td>235.000000</td>
      <td>4.500000</td>
    </tr>
  </tbody>
</table>
</div>



```python
print(len(df["model"].unique()))

```

    18
    


```python
print(df["transmission"].unique())
```

    ['Manual' 'Automatic' 'Semi-Auto' 'Other']
    


```python
print(df["fuelType"].unique())
```

    ['Petrol' 'Other' 'Hybrid' 'Diesel']
    


```python
print(len(df["fuelType"].unique()))
```

    4
    


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6738 entries, 0 to 6737
    Data columns (total 8 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   model         6738 non-null   object 
     1   year          6738 non-null   int64  
     2   price         6738 non-null   int64  
     3   transmission  6738 non-null   object 
     4   mileage       6738 non-null   int64  
     5   fuelType      6738 non-null   object 
     6   mpg           6738 non-null   float64
     7   engineSize    6738 non-null   float64
    dtypes: float64(2), int64(3), object(3)
    memory usage: 421.2+ KB
    


```python
df.isna().sum()
```




    model           0
    year            0
    price           0
    transmission    0
    mileage         0
    fuelType        0
    mpg             0
    engineSize      0
    dtype: int64



The relation between the numerical variables at matplotlib.pyplot
Scatterplot of mileage vs price
Scatterplot of mpg vs price


```python
plt.figure(figsize=(20,16))

plt.subplot(3, 1, 1)
sns.scatterplot(x="mileage", y="price", data=df)

plt.subplot(3, 1, 2)
sns.scatterplot(x="mpg", y="price", data=df)


plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    


For the scatterplot between mileage and price, with the increase of mileage that means with the using of car the price of car reduce. 
In case of the scatterplot between mpg and price, there is no clear visualization as we can see at the same value of mpg there is rise of price. So it is difficult to interprete the relation between mpg anf price.




```python
plt.figure(figsize=(20,16))

plt.subplot(2, 2, 1)
sns.scatterplot(x="mileage", y="price", data=df, hue="fuelType")

plt.subplot(2, 2, 2)
sns.scatterplot(x="mpg", y="price", data=df, hue="fuelType")


plt.tight_layout()
plt.show()
```


    
![png](output_14_0.png)
    


The scatterplot between mileage and price represents, with the increase of mileage for different fueltypes toyota car price increase or not. The increase of price with fuel type is,
    Diesel> Hybrid > Other > Petrol
That means perol running car require lower price with the increase of mileage. 
The second scatterplot shows the same result, petrol driving car require the highest price with the increase of mileage.




```python
plt.figure(figsize=(20,16))

plt.subplot(2, 2, 1)
sns.regplot(x="mileage", y="price", data=df, line_kws={"color":"red"})

plt.subplot (2,2,2)
sns.regplot (x="mpg", y="price", data=df, line_kws= {"color":"red"})

plt.tight_layout()
plt.show()
```


    
![png](output_17_0.png)
    


The first regression line shows that with the increase of the price also reduce.
It is also same for the regression line between mpg and price. With the increase of mpg, the price also reduce.
But the change is more incase of mileage than mpg. 


```python
penguins = sns.load_dataset("penguins")

display(penguins.head())
print(penguins.shape)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>species</th>
      <th>island</th>
      <th>bill_length_mm</th>
      <th>bill_depth_mm</th>
      <th>flipper_length_mm</th>
      <th>body_mass_g</th>
      <th>sex</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>39.1</td>
      <td>18.7</td>
      <td>181.0</td>
      <td>3750.0</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>39.5</td>
      <td>17.4</td>
      <td>186.0</td>
      <td>3800.0</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>40.3</td>
      <td>18.0</td>
      <td>195.0</td>
      <td>3250.0</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>36.7</td>
      <td>19.3</td>
      <td>193.0</td>
      <td>3450.0</td>
      <td>Female</td>
    </tr>
  </tbody>
</table>
</div>


    (344, 7)
    


```python
sns.pairplot(penguins)
plt.show()
```


    
![png](output_20_0.png)
    



```python
sns.pairplot(penguins, hue="species")
plt.show()
```


    
![png](output_21_0.png)
    


Pairplot for the DataFrame of Toyota


```python
sns.pairplot(df) 
plt.show()
```


    
![png](output_23_0.png)
    


Removing redundant information


```python
sns.pairplot(df, corner=True)
```




    <seaborn.axisgrid.PairGrid at 0x279b86a16d0>




    
![png](output_25_1.png)
    





```python
sns.pairplot(df, corner=True, hue="transmission")

```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:305: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:305: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:305: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:305: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:305: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    




    <seaborn.axisgrid.PairGrid at 0x279ba740f40>




    
![png](output_27_2.png)
    


To me, I think through this pairplot I can compare the changes easily with among many variables in one grph.
Like, regaring with the changes of year I can compare the changes of engiesize,mpg, mileahe, and price for different transmission like manual, automatic, semi-auto, and other.

